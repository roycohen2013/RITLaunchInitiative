def predicted_apogee(position,velocity,orientation):
return apogee
