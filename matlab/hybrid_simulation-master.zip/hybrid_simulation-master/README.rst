================
Sutton Hybrid Engine Modeling Program (S.H.E.M.P.)
================

**S.H.E.M.P.** is a collection of `MATLAB` files for simulating hybrid rocket 
engine performance.
